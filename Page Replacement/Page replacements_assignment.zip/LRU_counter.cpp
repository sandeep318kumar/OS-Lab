#include<bits/stdc++.h>
using namespace std;
int solve(int A[], int n, int k)
{
    int cc = 0;
    vector<int>v1, v2;
    int i = 0;
    while(v1.size() < k)
    {
        cout<<"Current Element is "<<A[i]<<endl<<"The Frame Window is ";
        for(int j=0;j<v1.size();j++){
            cout<<v1[j]<<" ";
        }
        cout<<endl;

        for(int j=0;j<v2.size();j++)
            v2[j]++;
        if(find(v1.begin(), v1.end(), A[i]) == v1.end()){
            v1.push_back(A[i]);
            v2.push_back(1);
            cc++;
        }
        i++;
    }
    while(i<n)
    {
        cout<<"Current Element is "<<A[i]<<endl<<"The Frame Window is ";
        for(int j=0;j<v1.size();j++){
            cout<<v1[j]<<" ";
        }
        cout<<endl;

        for(int j=0;j<v2.size();j++)
            v2[j]++;

        if(find(v1.begin(), v1.end(), A[i]) == v1.end()){
            int m1 = -1, m2 = INT_MAX;
            for(int j=0;j<v2.size();j++){
                if(v2[j] < m2){
                    m2 = v2[j];
                    m1 = j;
                }
            }
            v1[m1] = A[i];
            v2[m1] = 1;
            cc++;
        }
        i++;
    }
    return cc;
}
int main()
{
    int A[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1};
    // int A[] = {1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5};
    int n = sizeof(A)/sizeof(A[0]);
    int k = 3;
    cout<<"\nTotal Page Faults Are "<<solve(A, n, k);
    return 0;
}